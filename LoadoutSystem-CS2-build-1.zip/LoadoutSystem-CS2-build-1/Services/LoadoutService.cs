using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Admin;
using CounterStrikeSharp.API.Modules.Utils;
using Microsoft.Extensions.Localization;

using LoadoutSystem.Config;
using LoadoutSystem.Utils;
using LoadoutSystem.Models;

namespace LoadoutSystem.Services;

public class LoadoutService
{
    private readonly BaseConfigs _config;
    private readonly IStringLocalizer _localizer;
    private string _currentMap = "";

    public LoadoutService(BaseConfigs config, IStringLocalizer localizer)
    {
        _config = config;
        _localizer = localizer;
    }

    public void SetCurrentMap(string mapName)
    {
        _currentMap = mapName;
        Debug.DebugInfo("LoadoutService", $"Current map set to: {mapName}");
    }

    public void ProcessPlayerLoadouts(CCSPlayerController player)
    {
        if (!PlayerUtils.IsValidPlayer(player))
        {
            Debug.DebugWarning($"Invalid player for loadout processing: {player?.PlayerName ?? "null"}");
            return;
        }

        Debug.DebugInfo("LoadoutService", $"Processing loadouts for {player.PlayerName} ({PlayerUtils.GetTeamName(player.Team)})");

        var applicableLoadouts = GetApplicableLoadouts(player);
        if (!applicableLoadouts.Any())
        {
            Debug.DebugInfo("LoadoutService", $"No applicable loadouts found for {player.PlayerName}");
            return;
        }

        Debug.DebugInfo("LoadoutService", $"Found {applicableLoadouts.Count} applicable loadouts for {player.PlayerName}");

        ProcessAllLoadouts(player, applicableLoadouts);
    }

    private void ProcessAllLoadouts(CCSPlayerController player, List<ApplicableLoadout> loadouts)
    {
        var allWeaponsToGive = new List<string>();
        var existingWeapons = WeaponUtils.GetPlayerWeapons(player);
        var weaponsAlreadyProcessed = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var appliedLoadouts = new List<string>();

        Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} current weapons: {string.Join(", ", existingWeapons)}");

        foreach (var loadout in loadouts.OrderByDescending(l => l.Config.Priority))
        {
            Debug.DebugInfo("LoadoutService", $"Processing loadout {loadout.Key} for {player.PlayerName} with {loadout.Weapons.Length} weapons");
            bool loadoutHadWeapons = false;

            foreach (var weapon in loadout.Weapons)
            {
                if (string.IsNullOrWhiteSpace(weapon))
                {
                    Debug.DebugWarning($"Empty weapon found in loadout {loadout.Key}");
                    continue;
                }

                if (!WeaponUtils.IsValidWeapon(weapon))
                {
                    Debug.DebugWarning($"Invalid weapon {weapon} in loadout {loadout.Key}");
                    continue;
                }

                if (weaponsAlreadyProcessed.Contains(weapon))
                {
                    Debug.DebugInfo("LoadoutService", $"Weapon {weapon} already processed from another loadout, skipping");
                    continue;
                }

                if (_config.CheckExistingWeapons)
                {
                    if (ShouldGiveWeapon(player, weapon, existingWeapons, allWeaponsToGive))
                    {
                        allWeaponsToGive.Add(weapon);
                        weaponsAlreadyProcessed.Add(weapon);
                        loadoutHadWeapons = true;
                        Debug.DebugInfo("LoadoutService", $"Added {weapon} to give list for {player.PlayerName}");
                    }
                    else
                    {
                        Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has {weapon} or similar weapon in category, skipping");
                    }
                }
                else
                {
                    if (!weaponsAlreadyProcessed.Contains(weapon))
                    {
                        allWeaponsToGive.Add(weapon);
                        weaponsAlreadyProcessed.Add(weapon);
                        loadoutHadWeapons = true;
                    }
                }
            }

            if (loadoutHadWeapons)
            {
                appliedLoadouts.Add(loadout.Key);
            }
        }

        if (allWeaponsToGive.Any())
        {
            GiveWeaponsToPlayer(player, allWeaponsToGive);
            SendLoadoutConfirmationMessage(player, appliedLoadouts);
        }
        else
        {
            Debug.DebugInfo("LoadoutService", $"No weapons needed for {player.PlayerName} from any loadout");
        }
    }

    private void SendLoadoutConfirmationMessage(CCSPlayerController player, List<string> appliedLoadouts)
    {
        if (!appliedLoadouts.Any())
            return;

        var loadoutNames = string.Join(", ", appliedLoadouts);
        if (appliedLoadouts.Count == 1)
        {
            var message = _localizer["loadout_applied_single", loadoutNames];
            player.PrintToChat($"{_localizer["prefix"]} {message}");
        }
        else
        {
            var message = _localizer["loadout_applied_multiple", loadoutNames];
            player.PrintToChat($"{_localizer["prefix"]} {message}");
        }

        Debug.DebugInfo("LoadoutService", $"Sent loadout confirmation to {player.PlayerName}: {loadoutNames}");
    }

    private List<ApplicableLoadout> GetApplicableLoadouts(CCSPlayerController player)
    {
        var applicableLoadouts = new List<ApplicableLoadout>();
        if (_config.Loadouts.TryGetValue(_currentMap, out var mapLoadouts))
        {
            applicableLoadouts.AddRange(GetLoadoutsForPlayer(player, mapLoadouts, _currentMap));
        }

        if (_config.Loadouts.TryGetValue("ANY", out var anyLoadouts))
        {
            applicableLoadouts.AddRange(GetLoadoutsForPlayer(player, anyLoadouts, "ANY"));
        }

        return applicableLoadouts;
    }

    private List<ApplicableLoadout> GetLoadoutsForPlayer(CCSPlayerController player, Dictionary<string, LoadoutConfig> loadouts, string source)
    {
        var applicable = new List<ApplicableLoadout>();
        foreach (var (loadoutKey, loadoutConfig) in loadouts)
        {
            if (!loadoutConfig.Enabled)
            {
                Debug.DebugInfo("LoadoutService", $"Loadout {loadoutKey} is disabled, skipping");
                continue;
            }

            if (!string.IsNullOrWhiteSpace(loadoutConfig.Flags))
            {
                if (!AdminManager.PlayerHasPermissions(player, loadoutConfig.Flags))
                {
                    Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} lacks permissions for loadout {loadoutKey} (Required: {loadoutConfig.Flags})");
                    continue;
                }
            }

            var weapons = player.Team == CsTeam.CounterTerrorist ? loadoutConfig.CT : loadoutConfig.T;
            if (weapons == null || weapons.Length == 0)
            {
                Debug.DebugInfo("LoadoutService", $"No weapons configured for team {PlayerUtils.GetTeamName(player.Team)} in loadout {loadoutKey}");
                continue;
            }

            applicable.Add(new ApplicableLoadout
            {
                Key = loadoutKey,
                Config = loadoutConfig,
                Weapons = weapons,
                Source = source
            });

            Debug.DebugInfo("LoadoutService", $"Loadout {loadoutKey} from {source} is applicable for {player.PlayerName}");
        }

        return applicable;
    }

    private bool ShouldGiveWeapon(CCSPlayerController player, string weapon, List<string> existingWeapons, List<string> weaponsToGive)
    {
        if (existingWeapons.Contains(weapon, StringComparer.OrdinalIgnoreCase))
        {
            Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has exact weapon {weapon}");
            return false;
        }

        if (weaponsToGive.Contains(weapon, StringComparer.OrdinalIgnoreCase))
        {
            Debug.DebugInfo("LoadoutService", $"Weapon {weapon} already queued to be given to {player.PlayerName}");
            return false;
        }

        if (WeaponUtils.IsPrimaryWeapon(weapon))
        {
            bool hasPrimary = WeaponUtils.PlayerHasPrimaryWeapon(player);
            bool willGetPrimary = weaponsToGive.Any(WeaponUtils.IsPrimaryWeapon);

            Debug.DebugInfo("LoadoutService", $"Primary weapon check for {weapon}: hasPrimary={hasPrimary}, willGetPrimary={willGetPrimary}, RemoveExistingWeapons={_config.RemoveExistingWeapons}");

            if (hasPrimary || willGetPrimary)
            {
                if (_config.RemoveExistingWeapons)
                {
                    Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} has/will get primary weapon, but will be replaced with {weapon}");
                    return true;
                }
                else
                {
                    Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has/will get a primary weapon, skipping {weapon} (RemoveExistingWeapons=false)");
                    return false;
                }
            }
        }

        if (WeaponUtils.IsSecondaryWeapon(weapon))
        {
            bool hasSecondary = WeaponUtils.PlayerHasSecondaryWeapon(player);
            bool willGetSecondary = weaponsToGive.Any(WeaponUtils.IsSecondaryWeapon);
            if (hasSecondary || willGetSecondary)
            {
                if (_config.RemoveExistingWeapons)
                {
                    Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} has/will get secondary weapon, but will be replaced with {weapon}");
                    return true;
                }
                else
                {
                    Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has/will get a secondary weapon, skipping {weapon} (RemoveExistingWeapons=false)");
                    return false;
                }
            }
        }

        if (WeaponUtils.IsGrenade(weapon))
        {
            var currentGrenadeCount = WeaponUtils.CountGrenades(player);
            var pendingGrenadeCount = weaponsToGive.Count(WeaponUtils.IsGrenade);
            if (currentGrenadeCount + pendingGrenadeCount >= 4)
            {
                Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has/will get maximum grenades ({currentGrenadeCount + pendingGrenadeCount}), skipping {weapon}");
                return false;
            }

            if (WeaponUtils.PlayerHasWeapon(player, weapon))
            {
                Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has grenade {weapon}");
                return false;
            }
        }

        if (WeaponUtils.IsUtilityItem(weapon))
        {
            if (WeaponUtils.PlayerHasWeapon(player, weapon))
            {
                Debug.DebugInfo("LoadoutService", $"Player {player.PlayerName} already has utility item {weapon}");
                return false;
            }
        }

        return true;
    }

    private void GiveWeaponsToPlayer(CCSPlayerController player, List<string> weapons)
    {
        Debug.DebugInfo("LoadoutService", $"Giving {weapons.Count} weapons to {player.PlayerName}: {string.Join(", ", weapons)}");

        if (_config.RemoveExistingWeapons)
        {
            var categoriesToRemove = new HashSet<string>();
            foreach (var weapon in weapons)
            {
                var category = WeaponUtils.GetWeaponCategory(weapon);
                if (category != "Unknown" && category != "Knife")
                {
                    categoriesToRemove.Add(category);
                }
            }

            foreach (var category in categoriesToRemove)
            {
                Debug.DebugInfo("LoadoutService", $"Removing existing {category} weapons from {player.PlayerName}");
                WeaponUtils.RemoveWeaponsByCategory(player, category);
            }
        }

        float delay = 0.1f;
        foreach (var weapon in weapons)
        {
            PlayerUtils.SafeGiveNamedItem(player, weapon, delay);
            delay += 0.05f;
        }

        Debug.DebugInfo("LoadoutService", $"Completed weapon distribution for {player.PlayerName}");
    }
}