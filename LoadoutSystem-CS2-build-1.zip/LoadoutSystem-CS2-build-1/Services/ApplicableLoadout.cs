using LoadoutSystem.Config;

namespace LoadoutSystem.Models;

public class ApplicableLoadout
{
    public required string Key { get; set; }
    public required LoadoutConfig Config { get; set; }
    public required string[] Weapons { get; set; }
    public required string Source { get; set; }
}