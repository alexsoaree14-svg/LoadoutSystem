using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;

namespace LoadoutSystem.Utils;

public static class PlayerUtils
{
    public static bool IsValidPlayer(CCSPlayerController? player)
    {
        try
        {
            return player != null &&
                   player.IsValid &&
                   !player.IsBot &&
                   player.Connected == PlayerConnectedState.PlayerConnected &&
                   player.PlayerPawn.IsValid &&
                   player.PlayerPawn.Value != null &&
                   player.PlayerPawn.Value.IsValid &&
                   player.PawnIsAlive &&
                   (player.Team == CsTeam.CounterTerrorist || player.Team == CsTeam.Terrorist);
        }
        catch
        {
            return false;
        }
    }

    public static bool IsPlayerInValidTeam(CCSPlayerController? player)
    {
        return player?.Team == CsTeam.CounterTerrorist || player?.Team == CsTeam.Terrorist;
    }

    public static string GetTeamName(CsTeam team)
    {
        return team switch
        {
            CsTeam.CounterTerrorist => "CT",
            CsTeam.Terrorist => "T",
            CsTeam.Spectator => "SPEC",
            CsTeam.None => "NONE",
            _ => "UNKNOWN"
        };
    }

    public static void SafeGiveNamedItem(CCSPlayerController player, string weaponName, float delay = 0.1f)
    {
        if (!IsValidPlayer(player))
        {
            Debug.DebugWarning($"Cannot give weapon {weaponName} to invalid player");
            return;
        }

        if (delay > 0)
        {
            var timer = new CounterStrikeSharp.API.Modules.Timers.Timer(delay, () =>
            {
                if (IsValidPlayer(player))
                {
                    try
                    {
                        var handle = player.GiveNamedItem(weaponName);
                        if (handle != 0)
                        {
                            Debug.DebugInfo("PlayerUtils", $"Successfully gave {weaponName} to {player.PlayerName}");
                        }
                        else
                        {
                            Debug.DebugWarning($"Failed to give {weaponName} to {player.PlayerName} - Invalid handle");
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.DebugError($"Exception giving {weaponName} to {player.PlayerName}: {ex.Message}");
                    }
                }
            });
        }
        else
        {
            try
            {
                var handle = player.GiveNamedItem(weaponName);
                if (handle != 0)
                {
                    Debug.DebugInfo("PlayerUtils", $"Successfully gave {weaponName} to {player.PlayerName}");
                }
                else
                {
                    Debug.DebugWarning($"Failed to give {weaponName} to {player.PlayerName} - Invalid handle");
                }
            }
            catch (Exception ex)
            {
                Debug.DebugError($"Exception giving {weaponName} to {player.PlayerName}: {ex.Message}");
            }
        }
    }
}