using LoadoutSystem.Config;

namespace LoadoutSystem.Utils;

public static class Debug
{
    public static BaseConfigs? Config { get; set; }

    public static void DebugMessage(string message)
    {
        if (Config?.EnableDebug != true) return;
        Console.WriteLine($"================================= [ LoadoutSystem ] =================================");
        Console.WriteLine(message);
        Console.WriteLine("===================================================================================");
    }

    public static void DebugInfo(string category, string message)
    {
        if (Config?.EnableDebug != true) return;
        Console.WriteLine($"================================= [ LoadoutSystem - {category} ] =================================");
        Console.WriteLine(message);
        Console.WriteLine("===================================================================================");
    }

    public static void DebugError(string error)
    {
        if (Config?.EnableDebug != true) return;
        Console.WriteLine($"================================= [ LoadoutSystem - ERROR ] =================================");
        Console.WriteLine($"ERROR: {error}");
        Console.WriteLine("==========================================================================================");
    }

    public static void DebugWarning(string warning)
    {
        if (Config?.EnableDebug != true) return;
        Console.WriteLine($"================================= [ LoadoutSystem - WARNING ] =================================");
        Console.WriteLine($"WARNING: {warning}");
        Console.WriteLine("============================================================================================");
    }
}