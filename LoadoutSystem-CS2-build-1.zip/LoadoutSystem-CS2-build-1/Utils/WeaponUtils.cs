using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;

namespace LoadoutSystem.Utils;

public static class WeaponUtils
{
    public static readonly string[] WeaponsList =
    {
        "weapon_ak47", "weapon_aug", "weapon_awp", "weapon_bizon", "weapon_cz75a", "weapon_deagle", "weapon_elite",
        "weapon_famas", "weapon_fiveseven", "weapon_g3sg1", "weapon_galilar", "weapon_glock", "weapon_hkp2000",
        "weapon_m249", "weapon_m4a1", "weapon_m4a1_silencer", "weapon_mac10", "weapon_mag7", "weapon_mp5sd",
        "weapon_mp7", "weapon_mp9", "weapon_negev", "weapon_nova", "weapon_p250", "weapon_p90", "weapon_revolver",
        "weapon_sawedoff", "weapon_scar20", "weapon_sg556", "weapon_ssg08", "weapon_tec9", "weapon_ump45",
        "weapon_usp_silencer", "weapon_xm1014", "weapon_decoy", "weapon_flashbang", "weapon_hegrenade",
        "weapon_incgrenade", "weapon_molotov", "weapon_smokegrenade", "item_defuser", "item_cutters",
        "weapon_knife", "weapon_healthshot"
    };

    public static readonly HashSet<string> PrimaryWeapons = new()
    {
        "weapon_ak47", "weapon_aug", "weapon_awp", "weapon_famas", "weapon_galilar", "weapon_m4a1",
        "weapon_m4a1_silencer", "weapon_sg556", "weapon_ssg08", "weapon_g3sg1", "weapon_scar20",
        "weapon_bizon", "weapon_mac10", "weapon_mp5sd", "weapon_mp7", "weapon_mp9", "weapon_p90",
        "weapon_ump45", "weapon_mag7", "weapon_nova", "weapon_sawedoff", "weapon_xm1014",
        "weapon_m249", "weapon_negev"
    };

    public static readonly HashSet<string> SecondaryWeapons = new()
    {
        "weapon_glock", "weapon_hkp2000", "weapon_usp_silencer", "weapon_p250", "weapon_fiveseven",
        "weapon_tec9", "weapon_cz75a", "weapon_deagle", "weapon_revolver", "weapon_elite"
    };

    public static readonly HashSet<string> Grenades = new()
    {
        "weapon_hegrenade", "weapon_flashbang", "weapon_smokegrenade", "weapon_incgrenade",
        "weapon_molotov", "weapon_decoy"
    };

    public static readonly HashSet<string> UtilityItems = new()
    {
        "item_defuser", "item_cutters", "weapon_healthshot"
    };

    public static readonly HashSet<string> Knives = new()
    {
        "weapon_knife", "weapon_knife_t"
    };

    public static bool IsValidWeapon(string weaponName)
    {
        return WeaponsList.Contains(weaponName);
    }

    public static bool IsPrimaryWeapon(string weaponName)
    {
        return PrimaryWeapons.Contains(weaponName);
    }

    public static bool IsSecondaryWeapon(string weaponName)
    {
        return SecondaryWeapons.Contains(weaponName);
    }

    public static bool IsGrenade(string weaponName)
    {
        return Grenades.Contains(weaponName);
    }

    public static bool IsUtilityItem(string weaponName)
    {
        return UtilityItems.Contains(weaponName);
    }

    public static bool IsKnife(string weaponName)
    {
        return Knives.Contains(weaponName);
    }

    public static string GetWeaponCategory(string weaponName)
    {
        if (IsPrimaryWeapon(weaponName)) return "Primary";
        if (IsSecondaryWeapon(weaponName)) return "Secondary";
        if (IsGrenade(weaponName)) return "Grenade";
        if (IsUtilityItem(weaponName)) return "Utility";
        if (IsKnife(weaponName)) return "Knife";
        return "Unknown";
    }

    public static bool PlayerHasWeapon(CCSPlayerController player, string weaponName)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
            return false;

        return player.PlayerPawn.Value.WeaponServices.MyWeapons.Any(weaponHandle =>
            weaponHandle?.Value?.DesignerName?.Equals(weaponName, StringComparison.OrdinalIgnoreCase) == true);
    }

    public static bool PlayerHasPrimaryWeapon(CCSPlayerController player)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
        {
            Debug.DebugInfo("WeaponUtils", $"Player {player?.PlayerName} has null weapon services");
            return false;
        }

        var primaryWeapons = new List<string>();
        foreach (var weaponHandle in player.PlayerPawn.Value.WeaponServices.MyWeapons)
        {
            if (weaponHandle?.Value?.DesignerName != null && IsPrimaryWeapon(weaponHandle.Value.DesignerName))
            {
                primaryWeapons.Add(weaponHandle.Value.DesignerName);
            }
        }

        Debug.DebugInfo("WeaponUtils", $"Player {player.PlayerName} primary weapons: {string.Join(", ", primaryWeapons)}");
        return primaryWeapons.Any();
    }

    public static bool PlayerHasSecondaryWeapon(CCSPlayerController player)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
            return false;

        return player.PlayerPawn.Value.WeaponServices.MyWeapons.Any(weaponHandle =>
            weaponHandle?.Value?.DesignerName != null &&
            IsSecondaryWeapon(weaponHandle.Value.DesignerName));
    }

    public static int CountGrenades(CCSPlayerController player)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
            return 0;

        return player.PlayerPawn.Value.WeaponServices.MyWeapons.Count(weaponHandle =>
            weaponHandle?.Value?.DesignerName != null &&
            IsGrenade(weaponHandle.Value.DesignerName));
    }

    public static List<string> GetPlayerWeapons(CCSPlayerController player)
    {
        var weapons = new List<string>();

        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
        {
            Debug.DebugWarning($"Cannot get weapons for player {player?.PlayerName ?? "null"} - null weapon services");
            return weapons;
        }

        foreach (var weaponHandle in player.PlayerPawn.Value.WeaponServices.MyWeapons)
        {
            if (weaponHandle?.Value?.DesignerName != null)
            {
                weapons.Add(weaponHandle.Value.DesignerName);
            }
        }

        Debug.DebugInfo("WeaponUtils", $"Retrieved {weapons.Count} weapons for {player.PlayerName}: {string.Join(", ", weapons)}");
        return weapons;
    }

    public static void RemoveWeaponByName(CCSPlayerController player, string weaponName)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
            return;

        var weaponToRemove = player.PlayerPawn.Value.WeaponServices.MyWeapons.FirstOrDefault(weaponHandle =>
            weaponHandle?.Value?.DesignerName?.Equals(weaponName, StringComparison.OrdinalIgnoreCase) == true);

        if (weaponToRemove?.Value != null)
        {
            weaponToRemove.Value.Remove();
            Debug.DebugInfo("WeaponUtils", $"Removed weapon {weaponName} from {player.PlayerName}");
        }
    }

    public static void RemoveWeaponsByCategory(CCSPlayerController player, string category)
    {
        if (player?.PlayerPawn?.Value?.WeaponServices?.MyWeapons == null)
            return;

        var weaponsToRemove = new List<CHandle<CBasePlayerWeapon>>();

        foreach (var weaponHandle in player.PlayerPawn.Value.WeaponServices.MyWeapons)
        {
            if (weaponHandle?.Value?.DesignerName != null)
            {
                var weaponCategory = GetWeaponCategory(weaponHandle.Value.DesignerName);
                if (weaponCategory.Equals(category, StringComparison.OrdinalIgnoreCase))
                {
                    weaponsToRemove.Add(weaponHandle);
                }
            }
        }

        foreach (var weapon in weaponsToRemove)
        {
            weapon.Value?.Remove();
        }

        if (weaponsToRemove.Count > 0)
        {
            Debug.DebugInfo("WeaponUtils", $"Removed {weaponsToRemove.Count} {category} weapons from {player.PlayerName}");
        }
    }
}