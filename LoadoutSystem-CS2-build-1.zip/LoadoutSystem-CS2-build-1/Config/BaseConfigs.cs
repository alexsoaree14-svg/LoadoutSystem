using CounterStrikeSharp.API.Core;
using System.Text.Json.Serialization;

namespace LoadoutSystem.Config;

public class BaseConfigs : BasePluginConfig
{
    [JsonPropertyName("Loadouts")]
    public Dictionary<string, Dictionary<string, LoadoutConfig>> Loadouts { get; set; } = new()
    {
        {
            "ANY", new Dictionary<string, LoadoutConfig>
            {
                {
                    "LOADOUT_1", new LoadoutConfig
                    {
                        Flags = "@css/reservation",
                        CT = ["weapon_bizon", "weapon_elite", "weapon_healthshot", "weapon_hegrenade", "weapon_incgrenade", "weapon_flashbang"],
                        T = Array.Empty<string>()
                    }
                },
                {
                    "LOADOUT_2", new LoadoutConfig
                    {
                        CT = ["weapon_elite", "weapon_hegrenade", "weapon_incgrenade", "weapon_flashbang"],
                        T = Array.Empty<string>()
                    }
                }
            }
        }
    };

    [JsonPropertyName("AutoGiveOnSpawn")]
    public bool AutoGiveOnSpawn { get; set; } = true;

    [JsonPropertyName("CheckExistingWeapons")]
    public bool CheckExistingWeapons { get; set; } = true;

    [JsonPropertyName("RemoveExistingWeapons")]
    public bool RemoveExistingWeapons { get; set; } = false;

    [JsonPropertyName("EnableDebug")]
    public bool EnableDebug { get; set; } = false;
}

public class LoadoutConfig
{
    [JsonPropertyName("flags")]
    public string? Flags { get; set; }

    [JsonPropertyName("CT")]
    public string[] CT { get; set; } = Array.Empty<string>();

    [JsonPropertyName("T")]
    public string[] T { get; set; } = Array.Empty<string>();

    [JsonPropertyName("enabled")]
    public bool Enabled { get; set; } = true;

    [JsonPropertyName("priority")]
    public int Priority { get; set; } = 0;
}