# LoadoutSystem CS2
Automatic weapon loadout system for Counter-Strike 2 servers with team-specific configurations, map-based loadouts, and permission support.

## 🚀 Installation
1. Install [CounterStrikeSharp](https://github.com/roflmuffin/CounterStrikeSharp) and [Metamod](https://www.sourcemm.net/downloads.php/?branch=master)
2. Download [LoadoutSystem](https://github.com/yourrepo/LoadoutSystem-CS2/releases/latest) from releases
3. Extract and upload to your game server
4. Start server and configure the generated config file

---

## 📋 Main Configuration Parameters

| Parameter | Description | Default | Required |
|-----------|-------------|---------|----------|
| `Loadouts` | Map-based loadout configurations with team-specific weapons | See example below | **YES** |
| `AutoGiveOnSpawn` | Automatically give loadouts when players spawn | `true` | **YES** |
| `CheckExistingWeapons` | Check if player already has weapons before giving new ones | `true` | **YES** |
| `RemoveExistingWeapons` | Remove existing weapons before giving new ones | `false` | **YES** |
| `EnableDebug` | Enable debug console output | `true` | **YES** |

### Loadout Configuration Structure

```json
{
  "Loadouts": {
    "MAP_NAME_OR_ANY": {
      "LOADOUT_KEY": {
        "flags": "@css/vip",
        "CT": ["weapon_m4a1", "weapon_glock", "weapon_hegrenade"],
        "T": ["weapon_ak47", "weapon_glock", "weapon_hegrenade"],
        "enabled": true,
        "priority": 1
      }
    }
  }
}
```

### Loadout Settings Parameters

| Parameter | Description | Required |
|-----------|-------------|----------|
| `flags` | Flag required to receive this loadout (leave empty for all players) | **NO** |
| `CT` | Array of weapons for Counter-Terrorist team | **YES** |
| `T` | Array of weapons for Terrorist team | **YES** |
| `enabled` | Enable/disable this specific loadout | **YES** |
| `priority` | Priority level (higher numbers = higher priority) | **YES** |

---

## 🔫 Supported Weapons

- **Pistols**: `weapon_glock`, `weapon_hkp2000`, `weapon_usp_silencer`, `weapon_p250`, `weapon_fiveseven`, `weapon_tec9`, `weapon_cz75a`, `weapon_deagle`, `weapon_revolver`, `weapon_elite`
- **Rifles**: `weapon_ak47`, `weapon_m4a1`, `weapon_m4a1_silencer`, `weapon_aug`, `weapon_sg556`, `weapon_famas`, `weapon_galilar`
- **Sniper Rifles**: `weapon_awp`, `weapon_ssg08`, `weapon_g3sg1`, `weapon_scar20`
- **SMGs**: `weapon_mp9`, `weapon_mac10`, `weapon_mp7`, `weapon_ump45`, `weapon_p90`, `weapon_bizon`, `weapon_mp5sd`
- **Shotguns**: `weapon_nova`, `weapon_xm1014`, `weapon_sawedoff`, `weapon_mag7`
- **Machine Guns**: `weapon_m249`, `weapon_negev`

### Utility Items
- `weapon_hegrenade`, `weapon_flashbang`, `weapon_smokegrenade`, `weapon_incgrenade`, `weapon_molotov`, `weapon_decoy`, `item_defuser`, `weapon_healthshot`

---

## 📝 Configuration Examples

### Basic VIP Loadout
```json
{
  "Loadouts": {
    "ANY": {
      "VIP_LOADOUT": {
        "flags": "@css/vip",
        "CT": ["weapon_m4a1", "weapon_usp_silencer", "weapon_hegrenade", "weapon_flashbang", "item_defuser"],
        "T": ["weapon_ak47", "weapon_glock", "weapon_hegrenade", "weapon_flashbang"],
        "enabled": true,
        "priority": 1
      }
    }
  }
}
```

### Map-Specific Loadouts
```json
{
  "Loadouts": {
    "de_dust2": {
      "DUST2_RIFLES": {
        "flags": "",
        "CT": ["weapon_m4a1", "weapon_usp_silencer"],
        "T": ["weapon_ak47", "weapon_glock"],
        "enabled": true,
        "priority": 1
      }
    },
    "de_mirage": {
      "MIRAGE_SMG": {
        "flags": "",
        "CT": ["weapon_mp9", "weapon_p250"],
        "T": ["weapon_mac10", "weapon_tec9"],
        "enabled": true,
        "priority": 1
      }
    }
  }
}
```

### Multiple Priority Loadouts
```json
{
  "Loadouts": {
    "ANY": {
      "ADMIN_LOADOUT": {
        "flags": "@css/root",
        "CT": ["weapon_awp", "weapon_deagle", "weapon_hegrenade", "weapon_flashbang", "weapon_smokegrenade"],
        "T": ["weapon_awp", "weapon_deagle", "weapon_hegrenade", "weapon_flashbang", "weapon_smokegrenade"],
        "enabled": true,
        "priority": 10
      },
      "VIP_LOADOUT": {
        "flags": "@css/vip",
        "CT": ["weapon_m4a1", "weapon_usp_silencer", "weapon_hegrenade"],
        "T": ["weapon_ak47", "weapon_glock", "weapon_hegrenade"],
        "enabled": true,
        "priority": 5
      },
      "DEFAULT_LOADOUT": {
        "flags": "",
        "CT": ["weapon_famas", "weapon_hkp2000"],
        "T": ["weapon_galilar", "weapon_glock"],
        "enabled": true,
        "priority": 1
      }
    }
  }
}
```

---

## 📊 Support

For issues, questions, or feature requests, please visit our [GitHub Issues](https://github.com/yourrepo/LoadoutSystem-CS2/issues) page.