using CounterStrikeSharp.API;
using CounterStrikeSharp.API.Core;
using CounterStrikeSharp.API.Modules.Utils;
using CounterStrikeSharp.API.Core.Attributes.Registration;
using CounterStrikeSharp.API.Core.Attributes;

using LoadoutSystem.Config;
using LoadoutSystem.Services;
using LoadoutSystem.Utils;

namespace LoadoutSystem;

[MinimumApiVersion(300)]
public class LoadoutSystem : BasePlugin, IPluginConfig<BaseConfigs>
{
    public override string ModuleName => "LoadoutSystem";
    public override string ModuleVersion => "1.0.0";
    public override string ModuleAuthor => "luca.uy";
    public override string ModuleDescription => "Simple loadout system";

    private LoadoutService? _loadoutService;
    public required BaseConfigs Config { get; set; }

    public void OnConfigParsed(BaseConfigs config)
    {
        Config = config;
        Debug.Config = config;

        _loadoutService = new LoadoutService(config, Localizer);

        Debug.DebugInfo("Plugin", "Configuration parsed and LoadoutService initialized");
    }

    public override void Load(bool hotReload)
    {
        Debug.DebugInfo("Plugin", "LoadoutSystem plugin loading...");

        RegisterListener<Listeners.OnMapStart>(OnMapStart);
        RegisterListener<Listeners.OnMapEnd>(OnMapEnd);

        if (hotReload)
        {
            var currentMap = Server.MapName;
            _loadoutService?.SetCurrentMap(currentMap);
            Debug.DebugInfo("Plugin", $"Hot reload detected, current map: {currentMap}");
        }

        Debug.DebugInfo("Plugin", "LoadoutSystem plugin loaded successfully!");
    }

    public override void Unload(bool hotReload)
    {
        Debug.DebugInfo("Plugin", "LoadoutSystem plugin unloading...");

        _loadoutService = null;

        Debug.DebugInfo("Plugin", "LoadoutSystem plugin unloaded successfully!");
    }

    private void OnMapStart(string mapName)
    {
        _loadoutService?.SetCurrentMap(mapName);
        Debug.DebugInfo("Events", $"Map started: {mapName}");
    }

    private void OnMapEnd()
    {
        Debug.DebugInfo("Events", "Map ended");
    }

    [GameEventHandler]
    public HookResult OnPlayerSpawn(EventPlayerSpawn @event, GameEventInfo info)
    {
        var player = @event.Userid;
        if (player == null || !player.IsValid || player.IsBot)
        {
            Debug.DebugInfo("Events", $"Invalid player spawn event: {player?.PlayerName ?? "null"}");
            return HookResult.Continue;
        }

        if (!PlayerUtils.IsPlayerInValidTeam(player))
        {
            Debug.DebugInfo("Events", $"Player {player.PlayerName} not in valid team: {player.Team}");
            return HookResult.Continue;
        }

        if (!Config.AutoGiveOnSpawn)
        {
            Debug.DebugInfo("Events", "Auto give on spawn is disabled");
            return HookResult.Continue;
        }

        Debug.DebugInfo("Events", $"Player spawn: {player.PlayerName} ({PlayerUtils.GetTeamName(player.Team)})");

        Server.NextFrame(() =>
        {
            if (PlayerUtils.IsValidPlayer(player))
            {
                _loadoutService?.ProcessPlayerLoadouts(player);
            }
        });

        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerConnectFull(EventPlayerConnectFull @event, GameEventInfo info)
    {
        var player = @event.Userid;
        if (player == null || !player.IsValid || player.IsBot)
        {
            return HookResult.Continue;
        }

        Debug.DebugInfo("Events", $"Player connected: {player.PlayerName}");

        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerDisconnect(EventPlayerDisconnect @event, GameEventInfo info)
    {
        var player = @event.Userid;
        if (player != null && player.IsValid)
        {
            Debug.DebugInfo("Events", $"Player disconnected: {player.PlayerName}");
        }

        return HookResult.Continue;
    }

    [GameEventHandler]
    public HookResult OnPlayerTeam(EventPlayerTeam @event, GameEventInfo info)
    {
        var player = @event.Userid;
        if (player == null || !player.IsValid || player.IsBot)
        {
            return HookResult.Continue;
        }

        var newTeam = (CsTeam)@event.Team;

        Debug.DebugInfo("Events", $"Player {player.PlayerName} changed to team: {PlayerUtils.GetTeamName(newTeam)}");

        if (PlayerUtils.IsPlayerInValidTeam(player) && player.PawnIsAlive && Config.AutoGiveOnSpawn)
        {
            Server.NextFrame(() =>
            {
                if (PlayerUtils.IsValidPlayer(player))
                {
                    Debug.DebugInfo("Events", $"Processing loadouts after team change for {player.PlayerName}");
                    _loadoutService?.ProcessPlayerLoadouts(player);
                }
            });
        }

        return HookResult.Continue;
    }
}